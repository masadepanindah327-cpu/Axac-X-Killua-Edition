# Changelog

## v6.2

- Fixed a page-navigation connection retention issue by tracking page-scoped event connections separately and disconnecting them before rebuilding content.
- Changed Low Graphics world scanning to process descendants in batches of 250, yielding between batches to reduce large one-frame stalls.
- Registered `DescendantAdded` listeners before scanning existing objects to reduce the chance of missing newly created effects during activation.
- Guarded visual optimization against running after the GUI is destroyed or Low Graphics is disabled.
- Fixed a character-respawn race so delayed `CharacterAdded` callbacks exit if the GUI has already been destroyed.
- Updated version labels and GUI instance name to v6.2.
- Kept the executor identification gate before GUI creation.

## Validation

Static structural checks passed for block balance, delimiters, version labels, page-connection cleanup, batched scans, respawn callback ordering, and executor-gate ordering. No Roblox/Delta runtime test was available.
