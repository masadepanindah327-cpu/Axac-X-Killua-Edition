# AXAC X KILLUA EDITION

A Killua-inspired Roblox client-side utility interface with responsive layout, RGB styling, character diagnostics, and local visual controls.

## Current version

**v6.2**

## Features

- Delta executor identification gate
- Responsive window and mobile-friendly drag controls
- Home / About page with build and executor status
- Player diagnostics: character load state, health, humanoid state, and position
- Local-only head visibility toggle
- Low Graphics toggle for selected local visual effects and part shadows
- FPS and network ping display
- Crosshair toggle
- Cyan / violet accent selection and RGB border animation
- Reduced Motion setting
- Window centering, floating-button reset, and menu toggle
- Page-level event cleanup when navigating between pages
- Batched world scans to reduce long frame stalls when enabling Low Graphics

## File

`AXAC_X_KILLUA_EDITION.lua`

## Running

This is an executor-oriented client script, not a Roblox Studio `LocalScript` as-is. It checks for an executor identification function and exits unless the reported executor name contains `Delta`.

1. Open the script in a text editor and review the source.
2. Run it in the intended Delta client environment.
3. Open **PERFORMANCE** to toggle Low Graphics or Crosshair.
4. Open **PLAYER** to refresh character diagnostics or toggle local head visibility.
5. Open **APPEARANCE** to change the accent, RGB border, or reduced-motion setting.

The script only changes client-side visual properties. It does not grant the official Headless item, alter server-authoritative player stats, or guarantee a specific FPS. FPS depends on the device, the current experience, and the platform's frame-rate limits.

## Validation status

- Static source review completed for v6.2.
- Structural block/delimiter scan passed.
- Version and GUI-name consistency checked.
- Page event connections are disconnected during page changes and GUI cleanup.
- Low Graphics scans are batched and stop when the feature is disabled or the GUI is destroyed.
- Runtime execution in Roblox/Delta has **not** been performed in this environment; do not interpret static checks as proof of zero runtime bugs.

## Changelog

See [CHANGELOG.md](CHANGELOG.md).
